# VigilAI

AI Powered automated CCTV video surveillance and Alarm system

## How to run?
`python main.py`

## Things to do before running:

1. Look at Line **36**, **37**, **39** in utils.py
2. Look at line **7** in fight_detection.py

Secure your home, office and places you prefer with our **Vigil AI** - **Malaiappansrikanth**