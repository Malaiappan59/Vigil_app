import cv2
import requests
import json
from tkinter import filedialog
import utils

API_URL = 'http://127.0.0.1:5001'    # Specify here

resource_path = '/predict'
api_url = API_URL + resource_path

def detect_fight():
    # Open a file dialog to select a video file
    file_path = filedialog.askopenfilename(title="Select Video File", filetypes=[("Video files", "*.mp4;*.avi;*.mkv")])

    # Check if a file was selected
    if file_path:
        VIDEO_SOURCE = file_path

        cap = cv2.VideoCapture(VIDEO_SOURCE)
        frame_count = 0
        sent = False

        try:
            while cap.isOpened():
                ret, frame = cap.read()

                if not ret:
                    break
                
                frame_count += 1

                # process every 20th frame
                if frame_count % 20 == 0:

                    # Convert the frame to a byte array
                    _, img_encoded = cv2.imencode('.jpg', frame)
                    frame_bytes = img_encoded.tobytes()

                    # Prepare the headers for the POST request
                    headers = {'Content-Type': 'application/octet-stream'}

                    # Send the frame to the API
                    response = requests.post(api_url, data=frame_bytes, headers=headers)

                    # Print the API response
                    prediction = json.loads(response.text)
                    if prediction["predicted label"] == 1:
                        # cv2.imshow('Output', frame)
                        print(f"Fight detected! Frame saved at frame {frame_count}")
                        if not sent:
                            utils.save_frame_with_timestamp(frame, save_location='fight_frame')
                            utils.email_notify("Fight anomaly detected!", frame=frame)
                            sent = True
                    else:
                        pass
                    
                    frame_count = 0

                # cv2.imshow('Feed Frame', frame)

                # # Break the loop if 'q' key is pressed
                # if cv2.waitKey(25) & 0xFF == ord('q'):
                #     break
        except Exception as e:
            print(str(e))
        finally:
            # Release the video capture object and close all windows
            cap.release()
            # cv2.destroyAllWindows()
